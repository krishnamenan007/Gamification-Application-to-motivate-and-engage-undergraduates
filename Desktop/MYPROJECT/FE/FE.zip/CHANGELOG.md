## [1.0.0] 2021-10-05

### Original Release

- Started project from [Muse Ant Design Dashboard](https://www.creative-tim.com/product/muse-ant-design-dashboard?ref=changelog-madd)
- Updated all dependencies from [Muse Ant Design Dashboard](https://www.creative-tim.com/product/muse-ant-design-dashboard?ref=changelog-madd) and those dependencies that were not working with the new React v17+ API, were deleted and/or replaced

### Warning

_Warnings might appear while doing a clean npm install - they do not affect the UI or the functionality of the product, and they appear because of NodeJS and not from the product itself._
_This product was designed and developed using NodeJS version 14.16.0 LTS, so please make sure to have a compatible version of NodeJS._
